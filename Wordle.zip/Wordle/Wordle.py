import random

from colorama import init
#APCPD
#PRPPA
from functii import *

init(autoreset=True)

words = open("cuvinte.txt").read().split()
word = random.choice(words)

c = 0
while 1:
    print(word)
    x = input_word(c)  # x stocheaza cuvantul introdus de mine

    if len(x) > 5:
        print(Fore.RED + "Word is too long!")
    elif len(x) < 5:
        print(Fore.RED + "Word is too short!")
    elif len(x) == 5 and x not in words:
        print(Fore.RED + "Not in word list!")
    elif len(x) == 5:
        c += 1
        print(len_correct(word, x))
        if x == word:
            print(f"You guessed the word in {c} attempts!")
            break
