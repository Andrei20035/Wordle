from functii import len_correct

def main(word):
    with open("comunicare.txt", "w+") as f:
        last_line=""
        while 1:
            text=f.read()
            text_list=text.split("\n")
            if text_list[-1]==f"{word}0":
                print(f"{word}0")
                break
            if text_list[-1]!=last_line and text_list[-1].endswith("0"):
                last_line=text_list[-1]
                print(last_line)
                f.seek(0)
                f.write(len_correct(word,last_line[:-1],p=False)+"1")
            f.seek(0)

if __name__=="__main__":
    with open("cuvinte.txt", "r") as f:
        date = f.read().split("\n")
    for word in date:
        print(f"\n{word}\n")
        main(word)