import time
from collections import defaultdict
from math import log2
from tqdm import tqdm
from functii import len_correct



def main():
    suma_meciuri,numar_meciuri=0,0
    while 1:
        with open("comunicare.txt", "w+") as f:
            f.write("TARIE0")
            last_line = ""
            last_word = "TARIE"
            cuv_posibile = set(date)
            incercare = 0
            while 1:
                text = f.read()
                text_list = text.split("\n")
                if text_list[-1] != last_line and text_list[-1].endswith("1"):
                    incercare += 1
                    last_line = text_list[-1]
                    print(last_line)
                    cuvinte_noi = set()
                    for word in date:
                        if last_line[:-1] == len_correct(word, last_word, p=False):
                            cuvinte_noi.add(word)
                    cuv_posibile &= cuvinte_noi
                    if len(cuv_posibile) == 1:
                        f.seek(0)
                        f.write(f"{tuple(cuv_posibile)[0]}0")
                        numar_meciuri += 1
                        suma_meciuri+=incercare+1
                        print(f"Medie este de {suma_meciuri/numar_meciuri} in {numar_meciuri}")
                        break
                    entropy_max = 0
                    word_max = ""
                    for word in tqdm(date):
                        probabilitati = defaultdict(int)
                        for cuv in cuv_posibile:
                            pattern = len_correct(cuv, word, p=False)
                            probabilitati[pattern] += 1

                        entropy = sum([(i / 11454) * log2(11454 / i) for i in probabilitati.values()])
                        if entropy > entropy_max:
                            entropy_max = entropy
                            word_max = word
                    f.seek(0)
                    f.write(f"{word_max}0")
                    last_word = word_max
                f.seek(0)

if __name__=="__main__":
    with open("cuvinte.txt", "r") as f:
        date = f.read().split("\n")

        main()