Echipa: Rusu Andrei, gr. 131
        Donici Alexandru, gr.131
        Cristea Alexandru, gr.131

Proiectul contine: -jocul wordle in sine, fara limita de incercari("Wordle.py")
                   -fisierul "entropy.py" in care am aflat cel mai bun opener
                   -programul care ghiceste un nou cuvant ("server.py" si "client.py comunica intre ele prin fisierul "comunicare.txt")
                   -baza de date "cuvinte.txt"
                   -numarul mediu de incercari pentru ghicirea cuvintelor este aprox. 4.5
