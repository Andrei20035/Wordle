from collections import defaultdict
from functii import len_correct
from math import log2
from tqdm import tqdm
with open("cuvinte.txt","r") as f:
    date=f.read().split("\n")
open("entropie_cuvinte.txt", "w").close()

entropy_max=0
word_max=""
for word in tqdm(date):
    probabilitati=defaultdict(int)
    for guess in date:
        pattern=len_correct(word, guess, p=False)
        probabilitati[pattern]+=1

    entropy=sum([(i/11454)*log2(11454/i) for i in probabilitati.values()])
    with open("entropie_cuvinte.txt", "a") as g:
        g.write(f"{word} {entropy}\n")
    if entropy>entropy_max:
        entropy_max=entropy
        word_max=word

print(word_max,entropy_max)
