with open("entropie_cuvinte.txt","r+") as f:
    lista_sortata=sorted(f.read().split("\n"),key=lambda x: x[6:], reverse=True)
    print(lista_sortata)
with open("entropie_cuvinte.txt","w") as f:
    f.write("\n".join(lista_sortata))
