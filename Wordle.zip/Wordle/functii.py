from colorama import Back, Fore


def input_word(x):
    x += 1
    return input(f"Guess no. {x}: ").upper()


def len_correct(a, b,p=True):
    frequency = [0] * 6
    info=["g"]*5

    for k in range(len(b)):
        if a[k] == b[k]:
            frequency[k] += 1
    for i in range(len(b)):
        for j in range(len(a)):  # cuvantul de ghicit
            if b[i] == a[i]:
                if p: print(Back.GREEN + Fore.BLACK + b[i], end=" ")
                info[i]="G"
                break
            if b[i] == a[j]:
                if i == j:
                    if p: print(Back.GREEN + Fore.BLACK + b[i], end=" ")
                    info[i] ="G"
                    break
                elif i != j and frequency[j] == 0:
                    if p: print(Back.YELLOW + Fore.BLACK + b[i], end=" ")
                    info[i] ="Y"
                    break
        else:
            if p: print(Back.WHITE + Fore.BLACK + b[i], end=" ")
    if p: print("\n")
    return "".join(info)

